import express,{Express} from 'express'
import 'dotenv/config'

// routers
import { tscrudRoute } from './src/routes/userRoutes'


const app:Express = express()
app.use(express.json())

app.use('/user', tscrudRoute)



const PORT = process.env.PORT
app.listen(PORT, () => console.log(`server listening on http://localhost:${PORT}`))