import { postUserDetailsDao } from "../Dao/userDao";

//insert
export const userDetailsService = async (req: object) => {
    const result = await postUserDetailsDao(req);
    return result;
  };