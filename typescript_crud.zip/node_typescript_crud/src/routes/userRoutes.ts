import { Router } from "express";
import { userDetailsController } from "../controller/userController";

export const tscrudRoute = Router();

tscrudRoute.post('/insertUser',userDetailsController)