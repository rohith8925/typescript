import { Request, Response } from "express";
import { userDetailsService } from "../service/userDetailsService";

export const userDetailsController = async (req: Request, res: Response) => {
    const result = await userDetailsService(req.body);
    res.json(result);
  };
  