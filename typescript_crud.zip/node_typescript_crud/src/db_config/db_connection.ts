import oracledb from "oracledb";
import "dotenv/config";
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT; // returns json objects

export let connect: any;
async function connection() {
  try {
    connect = await oracledb.getConnection({
      user: process.env.USER_NAME,
      password: process.env.PASSWORD,
      connectString: process.env.CONNECTION_STRING,
    });
    console.log("👏 DataBase Connected Sucessfully");
  } catch (error) {
    console.log("😒 Unable to connect DataBase", error);
  }
}

connection();
