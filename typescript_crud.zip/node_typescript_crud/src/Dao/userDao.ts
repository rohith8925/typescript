import { connect } from "../db_config/db_connection";
import { message } from "../types/userTypes";
import { dbConnection } from "../Database/execution";
import { query } from "../Query/userQuery";

//insertUser
export const postUserDetailsDao = async (obj: any): Promise<message> => {
  try {
    console.log("User Post Method Invoked");

    let bindParams = {
      username: obj.USERNAME,

      email: obj.EMAIL,

      password: obj.PASSWORD,
    };

    let result = await dbConnection(query.insertQuery, bindParams);

    return {
      message: "success",

      data: result.data,
    };
  } catch (error) {
    console.log("Unable to insert the user Details", error);

    return {
      message: `0`,

      data: 0,
    };
  }
};
