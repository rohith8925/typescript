export const query = {
    insertQuery : "insert into xx1489_users_t(user_id,user_name,user_email,user_password)values(xx1489_users_s.nextval,:user_name,:user_email,:user_password"
}