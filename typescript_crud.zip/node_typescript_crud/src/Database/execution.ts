import { connect } from "../db_config/db_connection";

export async function dbConnection(query:String,bindParam?:object,opts?:object)
{
    try{
        let result = await connect.execute(query,bindParam || {}, opts || {})
    }
    catch(error)
    {
        throw error;
    }
    finally{
        if(connect)
        {
            await connect.close()
        }
    }

}

