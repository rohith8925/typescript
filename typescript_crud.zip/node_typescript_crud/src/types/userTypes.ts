export type userDetails = {
    user_id: number
    user_name: string
    user_email: string
    user_password : String
  };
  
  export type message = {
    message: string;
    data: number
  };
